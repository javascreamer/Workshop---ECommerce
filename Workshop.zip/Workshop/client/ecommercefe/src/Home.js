function Home() {
    return (
        <div>
            <h2>Welcome to E-Commerce Application</h2>
            <p>This is the Home Page.</p>
        </div>
    );
}
export default Home;

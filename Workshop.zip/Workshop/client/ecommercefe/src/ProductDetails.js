import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import axios from "axios";
import "./ProductDetails.css";

function ProductDetails() {

    const { id } = useParams();

    const [product, setProduct] = useState({});
    const [similarProducts, setSimilarProducts] = useState([]);

    useEffect(() => {

        loadProduct();

    }, [id]);

    const loadProduct = async () => {

        try {

            const response = await axios.get(
                `http://localhost:5000/api/products/${id}`
            );

            setProduct(response.data.product);

            setSimilarProducts(response.data.similarProducts);

        }
        catch (error) {

            console.log(error);

        }

    };

    return (

        <div>

            <div className="details-container">

                <img
                    src={product.image}
                    alt={product.name}
                    className="details-image"
                />

                <div>

                    <h2>{product.name}</h2>

                    <p>{product.description}</p>

                    <h3>₹ {product.price}</h3>

                    <p>
                        <strong>Category :</strong> {product.category}
                    </p>

                    <p>
                        <strong>Brand :</strong> {product.brand}
                    </p>

                    <p>
                        <strong>Rating :</strong> ⭐ {product.rating}
                    </p>

                    <button>
                        Add To Cart
                    </button>

                </div>

            </div>

            <hr />

            <h2>Similar Products</h2>

            <div className="products">

                {

                    similarProducts.map(item => (

                        <div
                            className="product"
                            key={item._id}
                        >

                            <img
                                src={item.image}
                                alt={item.name}
                                className="product-image"
                            />

                            <h3>{item.name}</h3>

                            <p>{item.description}</p>

                            <p>

                                ₹ {item.price}

                            </p>

                            <Link
                                to={`/products/${item._id}`}
                            >

                                <button>

                                    View Details

                                </button>

                            </Link>

                        </div>

                    ))

                }

            </div>

        </div>

    );

}

export default ProductDetails;
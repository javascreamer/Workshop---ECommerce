import { useState } from "react";
import axios from 'axios';

function Login() {

    const [message, setMessage] = useState("");

    const [user, setUser] = useState({
        email: "",
        password: ""
    });

    const handleChange = (event) => {

        const { name, value } = event.target;

        setUser({
            ...user,
            [name]: value
        });

    };

    const handleSubmit = async (event) => {

    event.preventDefault();

    console.log(user);

      try {

        const response = await axios.post(
            "http://localhost:5000/api/users/login",
            user
        );

        console.log(response.data);
         setMessage(response.data.message);


    } catch (error) {

        console.log(error);
         setMessage("Login Failed");


    }


};




    return (
        <div>

            <h2>User Login</h2>

             <p style={{fontWeight: "bold"}}>{message}</p>

            <form onSubmit={handleSubmit}>

                <div>
                    <label>Email</label>
                    <br />
                    <input
                        type="email"
                        name="email"
                        value={user.email}
                        onChange={handleChange}
                    />

                </div>

                <br />

                <div>
                    <label>Password</label>
                    <br />
                    <input
                        type="password"
                        name="password"
                        value={user.password}
                        onChange={handleChange}
                    />

                </div>

                <br />

                <button type="submit">
                    Login
                </button>

            </form>

        </div>
    );
}
export default Login;

import { useEffect, useState } from "react";
import axios from "axios";
import "./Product.css";

function Products() {

    const [products, setProducts] = useState([]);

    const [search, setSearch] = useState("");

    const [category, setCategory] = useState("All");

    const [sortBy, setSortBy] = useState("");

    const [page, setPage] = useState(1);

    const [hasMore, setHasMore] = useState(true);

    useEffect(() => {

        loadProducts(1, true);

    }, []);

    useEffect(() => {

        window.addEventListener("scroll", handleScroll);

        return () => {

            window.removeEventListener("scroll", handleScroll);

        };

    }, [page, hasMore]);

    const loadProducts = async (pageNumber, reset = false) => {

        try {

            const response = await axios.get(

                "http://localhost:5000/api/products",

                {

                    params: {

                        search,

                        category,

                        sortBy,

                        page: pageNumber,

                        limit: 6

                    }

                }

            );

            if (reset) {

                setProducts(response.data.products);

            }
            else {

                setProducts(previous => [

                    ...previous,

                    ...response.data.products

                ]);

            }

            setPage(pageNumber);

            setHasMore(pageNumber < response.data.totalPages);

        }
        catch (error) {

            console.log(error);

        }

    };

    const handleScroll = () => {

        if (

            window.innerHeight + window.scrollY >=

            document.documentElement.scrollHeight - 100

        ) {

            if (hasMore) {

                loadProducts(page + 1);

            }

        }

    };

    return (

        <div>

            <h2>Products</h2>

            <div className="products">

                {

                    products.map(product => (

                        <div

                            className="product"

                            key={product._id}

                        >

                            <img

                                src={product.image}

                                alt={product.name}

                                className="product-image"

                            />

                            <h3>{product.name}</h3>

                            <p>{product.description}</p>

                            <p>

                                ₹ {product.price}

                            </p>

                        </div>

                    ))

                }

            </div>

            {

                !hasMore &&

                <h3 style={{ textAlign: "center" }}>

                    No More Products

                </h3>

            }

        </div>

    );

}

export default Products;
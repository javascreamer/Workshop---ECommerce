import { useState } from "react";
import axios from 'axios';

function Register() {

    const [message, setMessage] = useState("");

    const [user, setUser] = useState({
        name: "",
        email: "",
        password: ""
    });

    const handleChange = (event) => {

        const { name, value } = event.target;

        setUser({
            ...user,
            [name]: value
        });

    };

    const handleSubmit = async (event) => {

    event.preventDefault();

    console.log(user);

      try {

        const response = await axios.post(
            "http://localhost:5000/api/users/register",
            user
        );

        console.log(response.data);
         setMessage(response.data.message);


    } catch (error) {

        console.log(error);
         setMessage("Registration Failed");


    }


};




    return (
        <div>

            <h2>User Registration</h2>

             <p style={{fontWeight: "bold"}}>{message}</p>

            <form onSubmit={handleSubmit}>

                <div>
                    <label>Name</label>
                    <br />
                    <input
                        type="text"
                        name="name"
                        value={user.name}
                        onChange={handleChange}
                    />

                </div>

                <br />

                <div>
                    <label>Email</label>
                    <br />
                    <input
                        type="email"
                        name="email"
                        value={user.email}
                        onChange={handleChange}
                    />

                </div>

                <br />

                <div>
                    <label>Password</label>
                    <br />
                    <input
                        type="password"
                        name="password"
                        value={user.password}
                        onChange={handleChange}
                    />

                </div>

                <br />

                <button type="submit">
                    Register
                </button>

            </form>

        </div>
    );
}
export default Register;

import { BrowserRouter, Routes, Route, Link } from "react-router-dom";

import Home from "./Home";
import Login from "./Login";
import Register from "./Register";
import Cart from "./Cart";
import Support from "./Support";
import Products from "./Products";
import ProductDetails from "./ProductDetails";

function App() {
    return (
        <BrowserRouter>

            <div style={{ padding: "20px" }}>

                <h1>E-Commerce Application</h1>

                <nav>
                    <Link to="/">Home</Link> |{" "}
                    <Link to="/login">Login</Link> |{" "}
                    <Link to="/register">Register</Link> |{" "}
                    <Link to="/cart">Cart</Link>|{" "}
                     <Link to="/support">Support</Link>|{" "}
                     <Link to="/products">Products</Link>
                </nav>

                <hr />

                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                    <Route path="/cart" element={<Cart />} />
                    <Route path="/support" element={<Support/>} />
                    <Route path="/products" element={<Products/>} />
                    <Route path="/products/:id" element={<ProductDetails/>} />
                    

                </Routes>

            </div>

        </BrowserRouter>
    );
}

export default App;

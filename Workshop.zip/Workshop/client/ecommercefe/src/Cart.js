import { useEffect, useState } from "react";
import axios from "axios";
import "./Cart.css";

const USER_ID = "6a3e34cc1a62cfa17a50208d";

function Cart() {

    const [cartItems, setCartItems] = useState([]);

    useEffect(() => {
        loadCart();
    }, []);

    const loadCart = async () => {

        const response = await axios.get(
            `http://localhost:5000/api/cart/${USER_ID}`
        );

        setCartItems(response.data);

    };

    const increaseQuantity = async (item) => {

        await axios.put(

            `http://localhost:5000/api/cart/${item._id}`,

            {
                quantity: item.quantity + 1
            }

        );

        loadCart();

    };

    const decreaseQuantity = async (item) => {

        if (item.quantity === 1) return;

        await axios.put(

            `http://localhost:5000/api/cart/${item._id}`,

            {
                quantity: item.quantity - 1
            }

        );

        loadCart();

    };

    const removeItem = async (id) => {

        await axios.delete(

            `http://localhost:5000/api/cart/${id}`

        );

        loadCart();

    };

    const grandTotal = cartItems.reduce(

        (total, item) =>

            total + item.quantity * item.productId.price,

        0

    );


    return (

        <div>

            <h2>Shopping Cart</h2>

            {

                cartItems.map(item => (

                    <div

                        className="cart-item"

                        key={item._id}

                    >

                        <img

                            src={item.productId.image}

                            alt={item.productId.name}

                            className="cart-image"

                        />

                        <div className="cart-details">

                            <h3>{item.productId.name}</h3>

                            <p>

                                <strong>Price :</strong>

                                ₹ {item.productId.price}

                            </p>

                            <div>

                                <button

                                    onClick={() => decreaseQuantity(item)}

                                >

                                    -

                                </button>

                                <span className="quantity">

                                    {item.quantity}

                                </span>

                                <button

                                    onClick={() => increaseQuantity(item)}

                                >

                                    +

                                </button>

                            </div>

                            <p>

                                <strong>Subtotal :</strong>

                                ₹ {item.productId.price * item.quantity}

                            </p>

                        </div>

                        <div>

                            <button

                                className="remove-btn"

                                onClick={() => removeItem(item._id)}

                            >

                                Remove

                            </button>

                        </div>

                    </div>

                ))

            }

            <hr />

            <h2>

                Grand Total : ₹ {grandTotal}

            </h2>

            <button className="checkout-btn">

                Proceed To Checkout

            </button>

        </div>


    );

}

export default Cart;

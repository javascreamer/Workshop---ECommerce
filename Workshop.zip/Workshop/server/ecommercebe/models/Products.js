
const mongoose = require("mongoose");

const productSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true
        },
        description: String,
        category: String,
        brand: String,
        price: Number,
        rating: Number,
        stock: Number,
        image: String
    },
    {
        timestamps: true
    }
);

module.exports = mongoose.model("Product", productSchema);

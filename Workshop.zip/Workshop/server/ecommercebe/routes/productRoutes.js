const express = require("express");
const router = express.Router();

const Product = require("../models/Products");

router.get("/:id", async (req, res) => {

    try {

        const product = await Product.findById(req.params.id);

        if (!product) {

            return res.status(404).json({
                message: "Product not found"
            });

        }

        const similarProducts = await Product.find({
            category: product.category,
            _id: { $ne: product._id }
        }).limit(4);

        res.status(200).json({
            product,
            similarProducts
        });

    }
    catch (error) {

        res.status(500).json({
            message: error.message
        });

    }

});


router.get("/", async (req, res) => {

    try {

        const { search, category, sortBy } = req.query;

        const page = Number(req.query.page) || 1;
        const limit = Number(req.query.limit) || 6;

        let query = {};
        let sort = {};

        // Search
        if (search) {
            query.name = {
                $regex: search,
                $options: "i"
            };
        }

        // Filter
        if (category && category !== "All") {
            query.category = category;
        }

        // Sorting
        switch (sortBy) {

            case "priceLowToHigh":
                sort.price = 1;
                break;

            case "priceHighToLow":
                sort.price = -1;
                break;

            case "rating":
                sort.rating = -1;
                break;

            case "name":
                sort.name = 1;
                break;

            default:
                break;

        }

        const products = await Product.find(query)
            .sort(sort)
            .skip((page - 1) * limit)
            .limit(limit);

        const totalProducts = await Product.countDocuments(query);

        res.json({

            products,

            totalProducts,

            currentPage: page,

            totalPages: Math.ceil(totalProducts / limit)

        });

    }
    catch (error) {

        res.status(500).json({

            message: error.message

        });

    }

});


module.exports = router;

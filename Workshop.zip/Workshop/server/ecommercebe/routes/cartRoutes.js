const express = require("express");
const router = express.Router();

const Cart = require("../models/Cart");

router.post("/", async (req, res) => {

    try {

        const { userId, productId, quantity } = req.body;

        const existingItem = await Cart.findOne({
            userId,
            productId
        });

        if (existingItem) {

            existingItem.quantity += quantity;

            await existingItem.save();

            return res.json({
                message: "Cart Updated"
            });

        }

        const cart = new Cart({
            userId,
            productId,
            quantity
        });

        await cart.save();

        res.status(201).json({
            message: "Product Added To Cart"
        });

    }
    catch (error) {

        res.status(500).json({
            message: error.message
        });

    }

});


router.get("/:userId", async (req, res) => {

    try {

        const cartItems = await Cart.find({
            userId: req.params.userId
        }).populate("productId");

        res.json(cartItems);

    }
    catch (error) {

        res.status(500).json({
            message: error.message
        });

    }

});


router.put("/:id", async (req, res) => {

    try {

        const cart = await Cart.findById(req.params.id);

        cart.quantity = req.body.quantity;

        await cart.save();

        res.json({
            message: "Quantity Updated"
        });

    }
    catch (error) {

        res.status(500).json({
            message: error.message
        });

    }

});


router.delete("/:id", async (req, res) => {

    try {

        await Cart.findByIdAndDelete(req.params.id);

        res.json({
            message: "Item Removed"
        });

    }
    catch (error) {

        res.status(500).json({
            message: error.message
        });

    }

});


module.exports = router;
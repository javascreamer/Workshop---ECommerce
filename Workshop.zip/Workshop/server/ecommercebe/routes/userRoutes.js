const express = require("express");
const User = require("../models/User");

const router = express.Router();

// Login API

router.post("/login", async (req, res) => {

    try {

        const { email, password } = req.body;

        const user = await User.findOne({
            email,
            password
        });

        if (user) {

            return res.status(200).json({
                message: "Login Successful"
            });

        }

        return res.status(401).json({
            message: "Invalid Email or Password"
        });

    }
    catch (error) {

        res.status(500).json({
            message: error.message
        });

    }

});


// Register User
router.post("/register", async (req, res) => {

    try {

        const { name, email, password } = req.body;

        const user = new User({
            name,
            email,
            password
        });

        await user.save();

        res.status(201).json({
            message: "User registered successfully",
            user
        });

    } catch (error) {

        res.status(500).json({
            message: error.message
        });
    }
});




module.exports = router;

const express = require("express");
const cors = require("cors");
const userRoutes = require("./routes/userRoutes");
const productRoutes = require("./routes/productRoutes");
const cartRoutes = require("./routes/cartRoutes");
const mongoose = require("mongoose");
require("dotenv").config(); 

mongoose
.connect(process.env.MONGO_URI)
.then(() => console.log("MongoDB Connected Successfully"))
.catch((err) => console.error("MongoDB Connection Failed:", err)); 


const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use("/api/users", userRoutes);
app.use("/api/products", productRoutes);
app.use("/api/cart", cartRoutes);


// POST  http://localhost:5000/api/users/register


// Home Route
app.get("/", (req, res) => {
    res.send("Welcome to the E-Commerce Backend API");
});

// localhost:5000

// Health Check API
app.get("/health", (req, res) => {
    res.status(200).json({
        status: "UP",
        message: "Server is running successfully"
    });
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
